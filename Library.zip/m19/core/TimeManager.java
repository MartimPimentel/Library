package m19.core;

import java.io.Serializable;

public class TimeManager implements Serializable{
    private int _day;

    /**
     * Method that advances the day based on daysToAdvance
     *
     * @param daysToAdvance
     */
    public void alterDate(int daysToAdvance){
        _day+=daysToAdvance;
    }

    /**
     * Return presente date
     *
     * @return current day
     */
    public int getDate(){
        return _day;
    }
}