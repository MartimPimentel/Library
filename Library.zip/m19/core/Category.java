package m19.core;

import java.io.Serializable;

/**
 * Category of a work
 */
public enum Category implements Serializable{
    FICTION("Ficção"),
    REFERENCE("Referência"),
    SCITECH("Técnica e Científica");

    private final String textRepresentation;

    /**
     * Constructor of a Category
     *
     * @param textRepresentation of a category
     */
    private Category(String textRepresentation) {
        this.textRepresentation = textRepresentation;
    }

    /**
     * @return the string description of a Category.
     * */
    @Override
    public String toString() {
        return textRepresentation;
    }
}
