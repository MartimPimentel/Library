package m19.core;
public interface Status{
    /**
     * Changes behaviour depending on number of works delivered late or not
     *
     * @param change -1 if late 1 if on time
     * @return new state
     * */
    public Status changeBehavior(int change);

    /**
     * Textual representation of the status
     *
     * @return description of behavior
     * */
    public String toString();

    /**
     * Gets the work's delivery Date
     *
     * @param total quantity of a book
     * @return deliveryDate depending on work's total quantity
     * */
    public int getDeliveryDate(int totalQuant);
}