package m19.core;
import java.io.Serializable;

public class Normal implements Status,Serializable {

    private int actualCounter;



    public Normal(int start){
        actualCounter = start;
    }
    /**
     * {@inheritDoc}
     * */
    @Override
    public Status changeBehavior(int change) {
        if (change > 0) {
            actualCounter += change;
        } else {
            if (actualCounter < 0) {
                actualCounter += change;
            } else {
                actualCounter = -1;
            }
        }

        if (actualCounter == -3) {
            return new Faltoso();
        }else if (actualCounter==5){
            return new Cumpridor();
        }else{
            return this;
        }
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public int getDeliveryDate(int totalQuant){
        if(totalQuant==1){
            return 3;
        }else if(totalQuant<=5){
            return 8;
        }else{
            return 15;
        }
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public String toString(){
        return "NORMAL";
    }
}