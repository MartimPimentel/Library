package m19.core;
import java.io.Serializable;

public abstract class Notification implements Serializable{
    final String _notificationType;
    private Work _work;

    /**
     * Notification contructor
     *
     * @param textual representation of the type of notification
     * @param instance of a work
     */
    public Notification(String notification, Work w){
        _work = w;
        _notificationType=notification + _work.toString();
    }

    /**
     * Method that gets a textual representation of a notification
     *
     * @return textual representation of a notification
     */
    public String getNotification(){
        return _notificationType;
    }
}