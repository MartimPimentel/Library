package m19.core;
import java.io.Serializable;

public class CheckRequestTwice implements Serializable,Rule{

    public int getId(){
        return 1;
    }

    /**
     * Method that sees if a work is currently requested
     * {@inheritDoc}
     */
    public boolean runRule(Work work,User user){
        return !(user.isWorkCurrentRequested(work));
    }
}