package m19.core;

public interface WorkSubject{
    /**
     * Add a User to a HashMap, _deliveryObserver or _requestObserver depending on interest
     *
     * @param user to add
     * @param interest that user has
     */
    public void attach(UserObserver u,Interest interest);

    /**
     * Remove a User from HashMap _deliveryObserver or _requestObserver depending on interest
     *
     * @param user to add
     * @param interest that user has
     */
    public void detach(UserObserver u,Interest interest);

    /**
     * Goes through all observers of an interest and sends them the notification according to interests
     *
     * @param instance of a notification
     * @param instance of a interest
     * */
    public void notifyUpdate(Notification notification,Interest interest);
}