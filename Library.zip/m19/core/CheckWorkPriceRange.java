package m19.core;
import java.io.Serializable;

public class CheckWorkPriceRange implements Serializable,Rule{

    public int getId(){
        return 6;
    }

    /**
     * Method that sees if a user can request a work based on his behavior and the works price
     * {@inheritDoc}
     */
    public boolean runRule(Work work,User user) {
        Status userStatus = user.getStatus();
        return !( (!(userStatus instanceof Cumpridor)) && work.getPrice() > 25);
    }
}