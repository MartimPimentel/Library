package m19.core;
import java.io.Serializable;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Collections;
import java.util.LinkedHashMap;

import m19.core.exception.*;

/**
 * Class that represents the library as a whole.
 */
public class Library implements Serializable {

  /** Serial number for serialization. */
  private static final long serialVersionUID = 201901101348L;
  private int _nextWorkId;
  private int _nextUserId;
  private Map<Integer,User> _users;
  private Map<Integer,Work> _works;
  private List<Request> _requests;
  private List<Rule> _rules;
  private TimeManager _time;

  /**
   * Constructor the library
   *
   * Initializes all variables of the library
   */
  public Library(){
    _users = new HashMap<Integer,User>();
    _works = new LinkedHashMap<Integer,Work>();
    _requests = new ArrayList<Request>();
    _rules = new ArrayList<Rule>();
    _time = new TimeManager();

    _nextUserId = 0;
    _nextWorkId = 0;

    _rules.add(new CheckRequestTwice());
    _rules.add(new CheckUserIsSuspended());
    _rules.add(new CheckWorkAvailability());
    _rules.add(new CheckUserNumberRequests());
    _rules.add(new CheckIsReferenceWork());
    _rules.add(new CheckWorkPriceRange());

  }

  /**
   * Method to register a User into the library
   *
   * @param name
   * @param email
   *
   * @throws UserRegistrationAbortsException if name or email are empty
   * @return Id of new user
   */
  public int createUser(String name,String email) throws UserRegistrationAbortsException{
    User u = new User(name,email,_nextUserId);
    int tempId = _nextUserId;
    _users.put(_nextUserId,u);
    _nextUserId++;
    return tempId;
  }

  /**
   * Method to search for a User in the library
   *
   * @param id
   *
   * @throws UserDoesntExistException if the UserId given doesnt exist in the library
   * @return user of a certain id
   */
  private User searchUserId(int id) throws UserDoesntExistException{
    if (_users.containsKey(id)){
      return _users.get(id);
    }else{
      throw new UserDoesntExistException();
    }
  }

  /**
   * Method to show a User of the library
   *
   * @param id
   *
   * @throws UserDoesntExistException if the UserId given doesnt exist in the library
   * @return Representation of the user of given id
   */
  public String showUser(int id) throws UserDoesntExistException{
    User u = this.searchUserId(id);
    return u.toString();
  }

  /**
   * Method returns all Users in form of a List<String>
   *
   * @return List<String> of all users
   */
  public List<String> showAllUsers(){
    List<User> users = new ArrayList<>(_users.values());
    List<String> res = new ArrayList<String>();
    Collections.sort(users,new UserComparator());
    Iterator<User> iter = users.iterator();

    while (iter.hasNext()){
        res.add(iter.next().toString());
    }
    return res;
  }

  /**
   * Method to search for a Work of the library
   * *
   * @param id
   *
   * @throws WorkDoesntExistException if the workId given doesnt exist in the library
   *
   * @return work of a certain id
   */
  private Work searchWorkId(int id) throws WorkDoesntExistException{
    if (_works.containsKey(id)){
      return _works.get(id);
    }else{
      throw new WorkDoesntExistException();
    }
  }

  /**
   * Method to show a Work of the library
   * *
   * @param id
   *
   * @throws WorkDoesntExistException if the workId given doesnt exist in the library
   *
   * @return Representation of the work of given id
   */
  public String showWork(int id) throws WorkDoesntExistException{
    Work w = searchWorkId(id);
    return w.toString();
  }

  /**
   * Method that returns all Works in a List<String>
   *
   * @return List<String> of all works
   */
  public List<String> showAllWorks(){
    List<String> res = new ArrayList<String>();
    Iterator<Work> iter = _works.values().iterator();

    while(iter.hasNext()){
        res.add(iter.next().toString());
    }
    return res;
  }

  /**
   * Method that check if all Rules are being followed to be able to request a book
   *
   * @param work
   * @param user
   *
   * @throws RuleAbortsException in case any rule fails
   *
   * @return List<String> of all users
   */
  private void checkAllRule(Work work,User user) throws RuleAbortsException{
    Iterator<Rule> iter = _rules.iterator();
      while(iter.hasNext()){
          Rule rule= iter.next();
          if (!rule.runRule(work,user)){
            throw new RuleAbortsException(rule.getId());
          }
      }
  }

  /**
   * Method that request a book to a user
   *
   * @param workId
   * @param userId
   *
   * @throws RuleAbortsException in case any rule fails
   * @throws WorkDoesntExistException if workId doesn't exist
   * @throws UserDoesntExistException if userId doesn't exist
   *
   * @return work delivery deadline
   */
  public int requestWork(int workId,int userId) throws RuleAbortsException, WorkDoesntExistException,UserDoesntExistException{
    User user = searchUserId(userId);
    Work work = searchWorkId(workId);
    checkAllRule(work,user);
    Request req = new Request(user,work,_time.getDate());
    _requests.add(req);
    user.addRequest(req);
    work.updateQuantity(-1);
    return req.getDeadline();
  }

  /**
   * Method that returns a book to a user
   *
   * @param workId
   * @param userId
   *
   * @throws WorkWasntBorrowedException if the Work wasn't borrowed
   * @throws WorkDoesntExistException if workId doesn't exist
   * @throws UserDoesntExistException if userId doesn't exist
   *
   * @return the fine that the user has to pay relatively to the work he has delivered
   */
  public int returnWork(int workId,int userId) throws WorkWasntBorrowedException, WorkDoesntExistException,UserDoesntExistException{
    int presentDate= _time.getDate();
    int delayedDays;
    User user = searchUserId(userId);
    Work work = searchWorkId(workId);
    Request req = user.removeRequest(work);

    req.changeDeliveredFlag();
    req.setDeliveredDate(presentDate);

    if (!req.wasLateDelivery()){
      user.changeStatus(1);
    }else{
      user.changeStatus(-1);
    }

    work.updateQuantity(1);
    delayedDays= presentDate -req.getDeadline();

    if (delayedDays>0) {
      user.updateFine(delayedDays);
    }
    _requests.remove(req);
    return user.getFine();
  }

  /**
   * Auxiliar method that changes the situation of a user acoording to its late(or not) requests
   *
   * @param number of days to advance
   */
  private void update(){
    Iterator<Request> it = _requests.iterator();

    while (it.hasNext()) {
      Request req = it.next();
      User user = req.getUser();

      if ((!req.wasDelivered()) && (_time.getDate()> req.getDeadline()) && (user.isActive())) {
        user.changeSituation();
      }
    }
  }

  /**
   * Method that advances the date and updates user's situation.
   *
   * @param number of days to avance.
   */
  public void advanceDate(int days){
    _time.alterDate(days);
    update();
  }

  /**
   * Method that gets the current date.
   *
   * @return current date
   */
  public int getDate(){
    return _time.getDate();
  }

  /**
   * Method that returns the next free workId.
   *
   * @return next free workId
   */
  public int get_nextWorkId(){
    return _nextWorkId;
  }

  /**
   * Method that returns the next free userId.
   *
   * @return next free userId.
   */
  public int get_nextUserId(){
    return _nextUserId;
  }

  /**
   * Method that advances userId to a available one.
   */
  public void advanceUserId(){
    _nextUserId++;
  }

  /**
   * Method that advances workId to a available one.
   */
  public void advanceWorkId(){
    _nextWorkId++;
  }

  /**
   * Method that adds a new user to the users hashMap.
   *
   * @param instance of a user.
   */
  public void addToUsers(User user){
    _users.put(_nextUserId,user);
  }

  /**
   * Method that adds a new work to the works linkedHashMap.
   *
   * @param instance of a work.
   */
  public void addToWorks(Work work){
    _works.put(_nextWorkId,work);
  }

  /**
   * Read the text input file at the beginning of the program and populates the
   * instances of the various possible types (books, DVDs, users).
   *
   * @param filename of the file to load
   * @throws BadEntrySpecificationException
   * @throws IOException
   */
  void importFile(String filename) throws BadEntrySpecificationException, IOException{
    Parser parser = new Parser(this);
    parser.parseFile(filename);
  }

  /**
   * Method that marks a user to a work to be notified when one of them is delivered.
   *
   * @param workId
   * @param userId
  */
  void addToInterestsDelivery(int workId, int userId){
    User user =  _users.get(userId);
    Work work = _works.get(workId);
    work.attach(user,Interest.DELIVERY);
  }

  /**
   * Method that marks a user to a work to be notified every time this work is requested.
   *
   * @param workId
   * @param userId
   */
  void addToInterestsRequest(int workId, int userId){
    User user =  _users.get(userId);
    Work work = _works.get(workId);
    work.attach(user,Interest.REQUEST);
  }

  /**
   * Method to show a user notifications.
   *
   * @param userId
   *
   * @throws UserDoesntExistException if the userId doesnt exists.
   *
   * @return List of all user notifications.
   */
  public List<String> showUserNotifications(int userId) throws UserDoesntExistException {
    User user = searchUserId(userId);
    return user.showNotifications();
  }

  /**
   * Method to pay all pendent user's fine.
   *
   * @param userId
   *
   * @throws UserDoesntExistException if the userId doesnt exists.
   * @throws UserActiveException if the user is active,therefore, has no pending fines.
   */
  public void payAllFines(int userId) throws UserDoesntExistException,UserActiveException{
    User user= searchUserId(userId);
    user.payAllFines(_time.getDate());
  }

  /**
   * Method that searches for works that contain a specific key
   *
   * @param keyWord to search
   *
   * @return List of all works that contain this keyWord.
   */
  public List<String> searchKeyWord(String key){
    List<String> res = new ArrayList<String>();
    Iterator<Work> iter = _works.values().iterator();
    while (iter.hasNext()){
      Work w = iter.next();
      if (w.searchKeyWord(key)){
        res.add(w.toString());
      }
    }
    return res;
  }
}

