package m19.core;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.io.Serializable;

public abstract class Work implements WorkSubject, Serializable{
    private int _workID;
    private int _totalQuantity;
    private int _availableQuantity;
    private String _title;
    private int _price;
    private String _type;
    private Set<UserObserver> _deliveryObserver;
    private List<UserObserver> _requestObserver;
    private Category _category;

    /**
     * Constructor of a Work
     *
     * @param id of a work
     * @param totalQuantity of a work
     * @param price of a work
     * @param title of a work
     * @param type of a work
     * @param category of a work
     */
    public Work(int id, int totalQuantity, int price, String title, String type, Category category){
        _workID = id;
        _totalQuantity = totalQuantity;
        _availableQuantity = totalQuantity;
        _price = price;
        _title = title;
        _type = type;
        _category = category;
        _deliveryObserver = new HashSet<UserObserver>();
        _requestObserver = new ArrayList<UserObserver>();
    }

    /**
     * Updates the quantity of available works by a number.
     *
     * @param quantity to add or remove from available quantity
     */
    public void updateQuantity(int quantity){
        if (_availableQuantity + quantity > _totalQuantity){
            _availableQuantity = _totalQuantity;
        }else if (_availableQuantity + quantity < 0){
            _availableQuantity = 0;
        }else {
            _availableQuantity+=quantity;
        }
        if (quantity>0){
            notifyUpdate(new DeliveryNotification(this),Interest.DELIVERY);
        }else{
            notifyUpdate(new RequestNotification(this),Interest.DELIVERY);
        }
    }

    /**
     * Add a User to a HashMap, _deliveryObserver or _requestObserver depending on interest
     *
     * @param user to add
     * @param interest that user has
     */
    @Override
    public void attach(UserObserver u, Interest interest){
        if (interest == Interest.DELIVERY){
            _deliveryObserver.add(u);
        }else{
            _requestObserver.add(u);
        }
    }

    /**
     * Remove a User from HashMap _deliveryObserver or _requestObserver depending on interest
     *
     * @param user to add
     * @param interest that user has
     */
    @Override
    public void detach(UserObserver user,Interest interest){
        if (interest == Interest.DELIVERY){
            _deliveryObserver.remove(user);
        }else{
            _requestObserver.remove(user);
        }
    }

    /**
     * Goes through all observers of an interest and sends them the notification according to interests
     *
     * @param instance of a notification
     * @param instance of a interest
     * */
    @Override
    public void notifyUpdate(Notification notification,Interest interest){
        if (interest == Interest.DELIVERY){
            for (UserObserver u: _deliveryObserver){
                u.update(notification);
            }
            _deliveryObserver.clear();
        }else{
            for (UserObserver u: _requestObserver){
                u.update(notification);
            }
        }
    }

    /**
     * Method that states the condicion of equal works.
     *
     * @param instance of a work to be compared with this one.
     *
     * @return true if are the same, false if not
     * */
    @Override
    public boolean equals(Object work){
        if (!(work instanceof Work)){
            return false;
        }
        Work castedWork= (Work) work;
        return this._workID==castedWork._workID;
    }

    /**
     * Method that gives the hashcode of a work.
     *
     * @return work hashcode,aka his work id.
     * */
    @Override
    public int hashCode(){
        return this._workID;
    }

    /**
     * Gets the textual representation of a work.
     *
     * @return the textual work representation.
     */
    @Override
    public String toString(){
        String result = Integer.toString(_workID)+" - "+Integer.toString(_availableQuantity)+" de "+Integer.toString(_totalQuantity);
        result += " - "+_type+" - "+_title+" - "+Integer.toString(_price)+" - "+ _category+" - ";
        return result;
    }

    /**
     * work price getter.
     *
     * @return Work price
     */
    public int getPrice(){
        return _price;
    }

    /**
     * Gets the work Id.
     *
     * @return Work id
     */
    public int getWorkID(){
        return _workID;
    }

    /**
     * Gets the available quantity of a work.
     *
     * @return work's available quantity
     */
    public int getAvailableQuantity(){
        return _availableQuantity;
    }

    /**
     * Gets the total quantity of a work.
     *
     * @return total quantity of a work
     * */
    public int getTotalQuantity(){
        return _totalQuantity;
    }


    /**
     * Gets a instance of the work category.
     *
     * @return work Category
     */
    public Category getCategory() {
        return _category;
    }

    /**
     * Returns list of interested users according to a interest
     *
     * @param interest
     *
     * @return list of all observers
     */
    public List<UserObserver> getInterstedUsers(Interest interest){
        if (interest == Interest.DELIVERY){
            List<UserObserver> temp = new ArrayList<UserObserver>();
            temp.addAll(_deliveryObserver);
            return temp;
        }else{
            return _requestObserver;
        }
    }

    /**
     * Searches for keyword in attribute
     *
     * @param  keyWord to search
     *
     * @return true if the work textual parameters contains the keyWord
     * */
    public boolean searchKeyWord(String key){
        return _title.toLowerCase().contains(key.toLowerCase());
    }
}