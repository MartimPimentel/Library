package m19.core;
import java.io.Serializable;
public class Cumpridor implements Status,Serializable {

    /**
     * {@inheritDoc}
     * */
    @Override
    public Status changeBehavior(int change){
        if (change<0){
            return new Normal(-1);
        }else{
            return this;
        }
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public int getDeliveryDate(int totalQuant){
        if(totalQuant==1){
            return 8;
        }else if(totalQuant<=5){
            return 15;
        }else{
            return 30;
        }
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public String toString(){
        return "CUMPRIDOR";
    }
}