package m19.core;

public interface Rule {

    /**
     * Returns id of a rule
     *
     * @return Rule Id
     */
    public int getId();

    /**
     * @param work to check rule
     * @param user to check rule
     *
     * @return true if rule checks
     */
    public boolean runRule(Work work,User user);
}