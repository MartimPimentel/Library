package m19.core;

public interface UserObserver{

    /**
     * Observer design pattern function: adds a new notification to this user.
     *
     * @param instance of a notification
     * */
    public void update(Notification notification);
}