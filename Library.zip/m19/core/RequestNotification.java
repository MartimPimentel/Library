package m19.core;

public class RequestNotification extends Notification{
    /**
     * {@inheritDoc}
     * */
    public RequestNotification(Work w){
        super("REQUISIÇÃO: ",w);
    }
}