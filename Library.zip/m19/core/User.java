package m19.core;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Iterator;
import java.io.Serializable;

import m19.core.exception.WorkWasntBorrowedException;
import m19.core.exception.BadEntrySpecificationException;
import m19.core.exception.UserRegistrationAbortsException;
import m19.core.exception.UserActiveException;

public class User implements UserObserver, Serializable{

    private int _userID;
    private String _userName;
    private String _userEmail;
    private User_Situation _userSituation;
    private Status _userStatus;
    private int _fine;
    private List<Request> _requestedWorks;
    private List<Request> _unpaidWorks;
    private List<Notification> _notifications;

    /**
     * Constructs a User.
     *
     * @param userName
     * @param userEmail
     * @param userId
     *
     * @throws BadEntrySpecificationException is the exception for bad userNames or userEmails.
     */
    public User(String userName,String userEmail,int Id) throws UserRegistrationAbortsException{

        if (userName==null || userName.trim().isEmpty()){           /*Checks if userName or userEmail are empty.*/
            throw new UserRegistrationAbortsException(userName,userEmail);
        }
        if (userEmail==null || userEmail.trim().isEmpty()){
            throw new UserRegistrationAbortsException(userName,userEmail);
        }
        _userName=userName;
        _userEmail=userEmail;
        _userID=Id;
        _userSituation= User_Situation.ACTIVO;
        _userStatus= new Normal(0);
        _requestedWorks= new ArrayList<Request>();
        _unpaidWorks= new ArrayList<Request>();
        _notifications = new ArrayList<Notification>();

    }

    /**
     * Overriding method that compares users by Id.
     *
     * @param Object variable
     * @return boolean if param given equals to this user
     */
    @Override
    public boolean equals(Object user){
        if (!(user instanceof User)){
            return false;
        }
        User castedUser= (User) user;
        return this._userID==castedUser.getUserId();
    }

    /**
     * Overriding method that gives the hashcode for a user.
     *
     * @return its hascode, aka userId
     */
    @Override
    public int hashCode(){
        return this._userID;
    }

    /**
     * Checks if user is active.
     *
     * @return true if user is active.
     */
    public boolean isActive(){
        return _userSituation==User_Situation.ACTIVO;
    }

    /**
     * Changes user Situation between ACTIVO and SUSPENSO.
     */
    public void changeSituation(){
        if (_userSituation==User_Situation.ACTIVO){
            _userSituation=User_Situation.SUSPENSO;
        }else{
            _userSituation=User_Situation.ACTIVO;
        }
    }

    /**
     * User Id getter method.
     *
     * @return a copy of userId.
     */
    public int getUserId(){
        return _userID;
    }

    /**
     * Changes user Status according to is late delivery entries.
     *
     * @param positive or negative number that represents if the delivery was in time or a late one.
     */
    public void changeStatus(int status){

        _userStatus=_userStatus.changeBehavior(status);
    }

    /**
     * User fine getter.
     *
     * @return total fine of user
     */
    public int getFine(){
        return _fine;
    }

    /**
     * Gets the user Status.
     *
     * @return the current user Status.
     */

    public Status getStatus(){
        return _userStatus;
    }

    /**
     * Method to convert a user into its textual representation.
     *
     * @return the textual user representation.
     */
    @Override
    public String toString(){
        String sentence=Integer.toString(_userID)+" - "+_userName+" - "+_userEmail+" - "+_userStatus.toString()+" - "+_userSituation;
        if (!this.isActive()){
            sentence+=" - EUR "+_fine;
        }
        return sentence;
    }

    /**
     * Updates user fine according to the number of delayed days.
     *
     * @param number of delayed days
     */
    public void updateFine(int numDays){

        _fine=_fine + 5*numDays;
    }

    /**
     * Pays all fines and checks if it is needed to change the situation of th user.
     *
     * @param current date
     */
    public void payAllFines(int date) throws UserActiveException{
        if(this.isActive()){
            throw new UserActiveException();
        }else{
            _fine = 0;
            _unpaidWorks.clear();
            for (Request req: _requestedWorks){
                if (req.getDeadline() < date){
                    return;
                }
            }
            this.changeSituation();
        }
    }

    /**
     * Gets the number of requests that are not delivered yet.
     *
     * @return user current number of requests.
     */
    public int getNumRequests(){
        return _requestedWorks.size();
    }

    /**
     * Adds to user List of current requests.
     *
     * @param instance of a request
     */
    public void addRequest(Request newRequest){
        _requestedWorks.add(newRequest);
    }

    /**
     * Removes request from user request list.
     *
     * @param work
     *
     * @throws WorkWasntBorrowedException if work is not in user list of current requested works.
     *
     * @return instance of the removed request
     */
    public Request removeRequest(Work work) throws WorkWasntBorrowedException{
        Iterator<Request> itr=_requestedWorks.iterator();
        while(itr.hasNext()){
            Request element=itr.next();

            if (element.compareWork(work)){
                _requestedWorks.remove(element);
                _unpaidWorks.add(element);
                return element;
            }
        }
        throw new WorkWasntBorrowedException();
    }

    /**
     * Checks if a given work has been requested by this user.
     *
     * @param instance of a work
     *
     * @return true if work is in user current requested list.
     */
    public boolean isWorkCurrentRequested(Work work){
        Iterator<Request> itr=_requestedWorks.iterator();
        while(itr.hasNext()){
            Request element=itr.next();
            
            if (element.compareWork(work)){
                    return true;
            }
        }
        return false;
    }

    /**
     * User name getter.
     *
     * @return the User userName.
     */
    public String getUserName(){
        return _userName;
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public void update(Notification notification){
        _notifications.add(notification);
    }

    /**
     * Gets all user notifications.
     *
     * @return List of the representation of all Notifications
     * */
    public List<String> showNotifications(){
        List<String> res = new ArrayList<String>();
        for (Notification n:_notifications){
            res.add(n.getNotification());
        }
        _notifications.clear();
        return res;
    }

    /**
     * Gets the delivery date of a work according to its total quantity and user Status.
     *
     * @param work's total quantity
     *
     * @return delivery date
     * */
    public int getDeliveryDate(int totalQuant){
        return _userStatus.getDeliveryDate(totalQuant);
    }
}