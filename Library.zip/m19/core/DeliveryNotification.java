package m19.core;

public class DeliveryNotification extends Notification{
    /**
     * {@inheritDoc}
     * */
    public DeliveryNotification(Work w){
       super("ENTREGA: ",w);
    }
}