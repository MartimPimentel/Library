package m19.core;

import java.util.Comparator;

public class UserComparator implements Comparator<User>{

    /**
     * @return int comparing to users by name
     * */
    public int compare(User user1, User user2){
        if (user1.getUserName().compareTo(user2.getUserName())==0){
            return user1.getUserId() - user2.getUserId();
        }else{
            return user1.getUserName().compareTo(user2.getUserName());
        }
    }
}