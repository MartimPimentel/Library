package m19.core;

import java.io.Serializable;

public enum Interest implements Serializable{
    DELIVERY,REQUEST;
}