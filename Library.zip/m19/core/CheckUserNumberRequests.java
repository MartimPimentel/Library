package m19.core;
import java.io.Serializable;

public class CheckUserNumberRequests implements Serializable,Rule{

    public int getId(){
        return 4;
    }

    /**
     * Method that sees if a user can request a work based on behavior
     * {@inheritDoc}
     */
    public boolean runRule(Work work,User user){
        int numRequests=user.getNumRequests();
        Status userStatus= user.getStatus();
        if (userStatus instanceof Cumpridor){
            if (numRequests<5){
                return true;
            }
        }else if(userStatus instanceof Normal){
            if (numRequests<3){
                return true;
            }
        }else{
            if (numRequests<1){
                return true;
            }
        }
        return false;
    }
}