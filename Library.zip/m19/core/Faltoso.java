package m19.core;
import java.io.Serializable;

public class Faltoso implements Status,Serializable{

    private int actualCounter=-3;

    /**
     * {@inheritDoc}
     * */
    @Override
    public Status changeBehavior(int change){
        if (change>0){
            actualCounter+=change;
        }else{
            actualCounter=-3;
        }

        if (actualCounter==0){
            return new Normal(3);
        }else{
            return this;
        }
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public int getDeliveryDate(int totalQuant){
        return 2;
    }

    /**
     * {@inheritDoc}
     * */
    @Override
    public String toString(){
        return "FALTOSO";
    }
}