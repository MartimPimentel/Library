package m19.core;
import java.io.Serializable;

public class CheckIsReferenceWork implements Serializable,Rule{

    public int getId(){
        return 5;
    }

    /**
     * Method that sees if a work is reference work
     * {@inheritDoc}
     */
    public boolean runRule(Work work,User user){
        
        return  work.getCategory()!=Category.REFERENCE;

    }
}