package m19.core;

import java.io.Serializable;

public class Request implements Serializable{

    private int _deadline;
    private User _user;
    private Work _work;
    private boolean _wasDelivered;
    private int _deliveredDate;

    /**
     * Request constructor
     *
     * @param instance of a user
     * @param instance of a work
     * @param current system date
     */
    public Request(User user,Work work,int currentDate){
        _user=user;
        _work=work;
        _wasDelivered= false;
        _deadline= currentDate + user.getDeliveryDate(work.getTotalQuantity());
    }

    /**
     * Gets a request deadline
     *
     * @return work request deadline
     */
    public int getDeadline(){
        return _deadline;
    }

    /**
     *  Method that compares 2 works
     *
     * @return true if are the same,false if not
     */
    public boolean compareWork(Work work){
        return _work.equals(work);
    }

    /**
     * Gets the instance of the user associated to this request
     *
     * @return user instance
     */
    public User getUser(){
        return _user;
    }

    /**
     * Gets the instance of the work associated to this request
     *
     * @return work instance
     */
    public Work getWork(){
        return _work;
    }

    /**
     * Checks if this is an active request or one that was delivered already
     *
     * @return true if was delivered, false if is an active request
     */
    public boolean wasDelivered(){
        return _wasDelivered;
    }

    /**
     * Changes the flag that states if the requested work was delivered
     */
    public void changeDeliveredFlag(){
        _wasDelivered= !_wasDelivered;
    }

    /**
     * Method that sets the delivery date of this work request
     *
     * @param delivery Date
     */
    public void setDeliveredDate(int date){
        _deliveredDate=date;
    }

    /**
     * Checks if the work was delivered late
     *
     * @return true if was delivered late,false if not
     */
    public boolean wasLateDelivery(){
        return  _deliveredDate > _deadline;
    }
}