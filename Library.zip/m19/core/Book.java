package m19.core;

public class Book extends Work{
    private String _author;
    private String _isbn;

    /**
     * Constructor of a book
     *
     * @param title of a book
     * @param author of a book
     * @param price of a book
     * @param category of a book
     * @param isbn of a book
     * @param totalQuantity of a book
     * @param id of a book
     */
    public Book(String title, String author, int price, Category category,String isbn,int totalQuantity,int id){
        super(id,totalQuantity,price,title,"Livro",category);
        _author = author;
        _isbn = isbn;
    }

    /**
     * @return the string description of a book.
     * */

    @Override
    public String toString(){
        String result = super.toString();
        result+= _author+" - "+_isbn;
        return result;
    }

    /**
     * @param keyWord to search
     * @return true if book author conatins the keyword
     * */
    @Override
    public boolean searchKeyWord(String key){
        return super.searchKeyWord(key) || _author.toLowerCase().contains(key.toLowerCase());
    }
}