package m19.core;

import java.io.Serializable;

/**
 * State of a user
 * */
public enum User_Situation implements Serializable{
    ACTIVO,SUSPENSO;
}