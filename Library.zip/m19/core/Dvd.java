package m19.core;

public class Dvd extends Work {
    private String _director;
    private String _ignac;

    /**
     * Constructor of a dvd
     *
     * @param title of a dvd
     * @param director of a dvd
     * @param price of a dvd
     * @param category of a dvd
     * @param ignac of a dvd
     * @param totalQuantity of a dvd
     * @param id of a dvd
     */
    public Dvd(String title,String director, int price, Category category, String ignac, int totalQuantity,int id){
        super(id,totalQuantity,price,title,"DVD",category);
        _director = director;
        _ignac = ignac;
    }

    /**
     * @return the string description of a Dvd.
     * */
    @Override
    public String toString(){
        String result = super.toString();
        result+= _director+" - "+_ignac;
        return result;
    }

    /**
     * @param keyWord to search
     * @return true if book author conatins the keyword
     * */
    @Override
    public boolean searchKeyWord(String key){
        return super.searchKeyWord(key) || _director.toLowerCase().contains(key.toLowerCase());
    }
}