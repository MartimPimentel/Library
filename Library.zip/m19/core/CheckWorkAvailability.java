package m19.core;
import java.io.Serializable;

public class CheckWorkAvailability implements Serializable,Rule{

    public int getId(){
        return 3;
    }

    /**
     * Method that sees if a work is currently available
     * {@inheritDoc}
     */
    public boolean runRule(Work work,User user){
        return (work.getAvailableQuantity()>0);
    }
}