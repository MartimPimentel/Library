package m19.core.exception;

/**
 * Class encoding reference to an invalid user state.
 */
public class UserActiveException extends Exception {

}