package m19.core.exception;

public class RuleAbortsException extends Exception {
    private int _ruleIndex;

    public RuleAbortsException(int ruleIndex){
        _ruleIndex=ruleIndex;
    }

    public int getFailedRuleIndex(){
        return _ruleIndex;
    }
}