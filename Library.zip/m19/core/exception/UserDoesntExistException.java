package m19.core.exception;

public class UserDoesntExistException extends Exception {

}