package m19.core.exception;

public class WorkWasntBorrowedException extends Exception {

}