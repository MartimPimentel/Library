package m19.core.exception;

public class WorkDoesntExistException extends Exception {

}