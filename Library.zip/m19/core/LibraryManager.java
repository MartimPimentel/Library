package m19.core;

import java.util.List;
import java.io.IOException;
import java.io.FileNotFoundException;

import m19.core.exception.MissingFileAssociationException;
import m19.core.exception.BadEntrySpecificationException;
import m19.core.exception.UserRegistrationAbortsException;
import m19.core.exception.ImportFileException;
import m19.core.exception.WorkWasntBorrowedException;
import m19.core.exception.RuleAbortsException;
import m19.core.exception.WorkDoesntExistException;
import m19.core.exception.UserDoesntExistException;
import m19.core.exception.UserActiveException;

import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;

/**
 * The façade class.
 */
public class LibraryManager {

  private Library _library;
  private String _filename;

  public LibraryManager(){
    _library = new Library();
  }

  /**
   * Serialize the persistent state of this application.
   *
   * @throws MissingFileAssociationException if the name of the file to store the persistent
   *         state has not been set yet.
   * @throws IOException if some error happen during the serialization of the persistent state

   */
  public void save() throws MissingFileAssociationException, IOException {
    if (_filename!=null) {
      try (FileOutputStream fileOut = new FileOutputStream(_filename);
           ObjectOutputStream out = new ObjectOutputStream(fileOut)){
        out.writeObject(_library);
      }
    }else{
      throw new MissingFileAssociationException();
    }
  }

  /**
   * Serialize the persistent state of this application into the specified file.
   *
   * @param filename the name of the target file
   *
   * @throws MissingFileAssociationException if the name of the file to store the persistent
   *         is not a valid one.
   * @throws IOException if some error happen during the serialization of the persistent state
   */
  public void saveAs(String filename) throws MissingFileAssociationException, IOException {
    _filename = filename;
    save();
  }

  /**
   * Recover the previously serialized persitent state of this application.
   *
   * @param filename the name of the file containing the perssitente state to recover
   *
   * @throws IOException if there is a reading error while processing the file
   * @throws FileNotFoundException if the file does not exist
   * @throws ClassNotFoundException
   */
  public void load(String filename) throws FileNotFoundException, IOException, ClassNotFoundException {
    try (FileInputStream fileIn = new FileInputStream(filename);
         ObjectInputStream in = new ObjectInputStream(fileIn)){
      _library = (Library) in.readObject();
      _filename = filename;
    }
  }

  /**
   * Set the state of this application from a textual representation stored into a file.
   *
   * @param datafile the filename of the file with the textual represntation of the state of this application.
   * @throws ImportFileException if it happens some error during the parsing of the textual representation.
   */
  public void importFile(String datafile) throws ImportFileException {
    try {
      _library.importFile(datafile);
    } catch (IOException | BadEntrySpecificationException e) {
      throw new ImportFileException(e);
    }
  }

  /**
   * Returns all users in their textual representation inside of a arrayList.
   *
   * @return List of all users
   */
  public List<String> getAllUsers(){
    return _library.showAllUsers();
  }

  /**
   * returns an instance of a user given by his Id.
   *
   * @param userId
   * @throws UserDoesntExistException if user doesnt exist.
   *
   * @return user string description
   */
  public String getUser(int id) throws UserDoesntExistException{
    return _library.showUser(id);
  }

  /**
   * returns the current system date.
   *
   * @return current date
   */
  public int getCurrentDate(){
    return _library.getDate();
  }

  /**
   * Advances the current date.
   *
   * @param number days to advance.
   */
  public void advanceDays(int nDays){
    _library.advanceDate(nDays);
  }

  /**
   * Creates a new user and returns his userId.
   *
   * @param userName
   * @param userEmail
   * @throws UserRegistrationAbortsException if userName or userEmail is empty.
   *
   * @return userId
   */
  public int registerUser(String userName,String userEmail) throws UserRegistrationAbortsException{
    return _library.createUser(userName,userEmail);
  }

  /**
   * returns all works in their textual representation inside a ArrayList.
   *
   * @return List of all works
   */
  public List<String> getAllWorks(){
    return _library.showAllWorks();
  }

  /**
   * returns the textual representation of a work.
   *
   * @param id
   * @throws WorkDoesntExistException if work doesnt exist.
   *
   * @return work in string representation
   */
  public String getWork(int id) throws WorkDoesntExistException{
    return _library.showWork(id);
  }

  /**
   * Requests a work and assign it to a user.
   *
   * @param workId
   * @param userId
   * @throws RuleAbortsException if doesnt pass one of the rules.
   * @throws WorkDoesntExistException if the work doesnt exist.
   * @throws UserDoesntExistException if the user doesnt exist.
   *
   * @return work's delivery deadline
   */
  public int requestWork(int workId,int userId) throws RuleAbortsException, WorkDoesntExistException,UserDoesntExistException{
    return _library.requestWork(workId, userId);
  }

  /**
   * returns a work that has been requested by a user.
   *
   * @param workId
   * @param userId
   * @throws WorkWasntBorrowedException if the work hasnt been assigned to this user.
   * @throws WorkDoesntExistException if the work doesnt exist.
   * @throws UserDoesntExistException if the user doesnt exist.
   *
   * @return fine user has to pay relatively to this work
   */
  public int returnWork(int workId, int userId) throws WorkWasntBorrowedException, WorkDoesntExistException,UserDoesntExistException{
    return _library.returnWork(workId,userId);
  }

  /**
   *  checks if there is a file associated to the system.
   *
   * @return true if is already associated
   */
  public boolean existsFile(){
    return _filename!=null;
  }

  /**
   *  Marks a user to receive a delivery notification if one of the works is delivered
   *
   * @param workId
   * @param userId
   */
  public void addToInterestsDelivery(int workId, int userId){
    _library.addToInterestsDelivery(workId,userId);
  }

  /**
   * Method to show all user's notification.
   *
   * @param userId
   * @throws UserDoesntExistException if the user doesnt exist.
   *
   * @return List of all user notififications
   */
  public List<String> showUserNotifications(int userId) throws UserDoesntExistException {
    return _library.showUserNotifications(userId);
  }

  /**
   * Method to pay all pending user fines
   *
   * @param userId
   * @throws UserDoesntExistException if the user doesnt exist.
   * @throws UserActiveException if the user is active,therefore, has no fines to pay.
   */
  public void payAllFines(int id) throws UserDoesntExistException,UserActiveException{
    _library.payAllFines(id);
  }

  /**
   * Method to search in all works for a keyword.
   *
   * @param keyword to search
   *
   * @return List of all works(in their representation form) that contain this keyword
   */
  public List<String> searchKeyWord(String key){
    return _library.searchKeyWord(key);
  }
}


