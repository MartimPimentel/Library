package m19.core;
import java.io.Serializable;

public class CheckUserIsSuspended implements Serializable,Rule{

    public int getId(){
        return 2;
    }

    /**
     * Method that sees if a user is currntly is active
     * {@inheritDoc}
     */
    public boolean runRule(Work work,User user){
        return (user.isActive());
    }
}