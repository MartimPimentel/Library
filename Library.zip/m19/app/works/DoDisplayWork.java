package m19.app.works;

import m19.core.LibraryManager;
import m19.core.Work;
import pt.tecnico.po.ui.Command;

import pt.tecnico.po.ui.DialogException;

import pt.tecnico.po.ui.Form;
import pt.tecnico.po.ui.Input;
import  m19.app.exception.NoSuchWorkException;
import m19.core.exception.WorkDoesntExistException;

/**
 * 4.3.1. Display work.
 */
public class DoDisplayWork extends Command<LibraryManager> {
  private Input<Integer> _workId;

  /**
   * @param receiver
   */
  public DoDisplayWork(LibraryManager receiver) {
    super(Label.SHOW_WORK, receiver);
    _workId = _form.addIntegerInput(Message.requestWorkId());
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException {
    _form.parse();
    int workId = _workId.value();
    try {
      String work = _receiver.getWork(workId);
      _display.popup(work);
    }catch (WorkDoesntExistException wdee){
      throw new NoSuchWorkException(workId);
    }
  }
  
}
