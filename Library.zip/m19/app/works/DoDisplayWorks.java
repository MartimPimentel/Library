package m19.app.works;

import m19.core.LibraryManager;

import pt.tecnico.po.ui.Command;
import java.util.List;

/**
 * 4.3.2. Display all works.
 */
public class DoDisplayWorks extends Command<LibraryManager> {
  /**
   * @param receiver
   */
  public DoDisplayWorks(LibraryManager receiver) {
    super(Label.SHOW_WORKS, receiver);
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() {
    List<String> works = _receiver.getAllWorks();
    for (String work : works){
      _display.addLine(work);
    }
    _display.display();
    _display.clear();
  }
}
