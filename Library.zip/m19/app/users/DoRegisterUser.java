package m19.app.users;

import m19.core.LibraryManager;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import pt.tecnico.po.ui.Input;
import m19.app.exception.UserRegistrationFailedException;
import m19.core.exception.BadEntrySpecificationException;
import m19.core.exception.UserRegistrationAbortsException;
/**
 * 4.2.1. Register new user.
 */
public class DoRegisterUser extends Command<LibraryManager> {
  private Input<String> _name;
  private Input<String> _email;

  /**
   * @param receiver
   */
  public DoRegisterUser(LibraryManager receiver) {
    super(Label.REGISTER_USER, receiver);
    _name = _form.addStringInput(Message.requestUserName());
    _email = _form.addStringInput(Message.requestUserEMail());
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException {
    _form.parse();
    String name=_name.value();
    String email=_email.value();
    try{
      int userId = _receiver.registerUser(name,email);
      _display.popup(Message.userRegistrationSuccessful(userId));
    }catch (UserRegistrationAbortsException urae){
      throw new UserRegistrationFailedException(name,email);
    }

  }

}
