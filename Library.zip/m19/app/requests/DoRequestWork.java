package m19.app.requests;

import m19.core.LibraryManager;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;
import pt.tecnico.po.ui.Form;
import pt.tecnico.po.ui.Input;

import m19.core.exception.RuleAbortsException;
import m19.core.exception.WorkDoesntExistException;
import m19.core.exception.UserDoesntExistException;
import m19.app.exception.RuleFailedException;
import m19.app.exception.NoSuchWorkException;
import m19.app.exception.NoSuchUserException;

/**
 * 4.4.1. Request work.
 */
public class DoRequestWork extends Command<LibraryManager> {

  private Input<Integer> _userId;
  private Input<Integer> _workId;
  private Input<Boolean> _wants2BeNotified;
  private Form _form2;
  /**
   * @param receiver
   */
  public DoRequestWork(LibraryManager receiver) {
    super(Label.REQUEST_WORK, receiver);
    _userId = _form.addIntegerInput(Message.requestUserId());
    _workId = _form.addIntegerInput(Message.requestWorkId());
    _form2= new Form();
    _wants2BeNotified = _form2.addBooleanInput(Message.requestReturnNotificationPreference());
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException {
    _form.parse();
    int userId= _userId.value();
    int workId= _workId.value();
    try{
      int deadline = _receiver.requestWork(workId,userId);
      _display.popup(Message.workReturnDay(workId,deadline));
    }catch (RuleAbortsException rae){
      if (rae.getFailedRuleIndex()==3){
        _form2.parse();
        if (_wants2BeNotified.value()){
          _receiver.addToInterestsDelivery(workId,userId);
        }
      }else{
        throw new RuleFailedException(userId,workId,rae.getFailedRuleIndex());
      }
    }catch (WorkDoesntExistException wdee){
      throw new NoSuchWorkException(workId);
    }catch (UserDoesntExistException udee){
      throw new NoSuchUserException(userId);
    }
  }

}
