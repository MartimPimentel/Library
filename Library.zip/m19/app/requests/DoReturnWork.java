package m19.app.requests;

import m19.core.LibraryManager;
import pt.tecnico.po.ui.Command;
import pt.tecnico.po.ui.DialogException;

import pt.tecnico.po.ui.Form;
import pt.tecnico.po.ui.Input;
import m19.core.exception.WorkWasntBorrowedException;
import m19.app.exception.WorkNotBorrowedByUserException;
import m19.core.exception.WorkDoesntExistException;
import m19.app.exception.NoSuchWorkException;
import m19.core.exception.UserDoesntExistException;
import m19.app.exception.NoSuchUserException;
import m19.core.exception.UserActiveException;
import m19.app.exception.UserIsActiveException;

/**
 * 4.4.2. Return a work.
 */
public class DoReturnWork extends Command<LibraryManager> {

  private Input<Integer> _userId;
  private Input<Integer> _workId;
  private Input<Boolean> _wantsToPay;
  private Form _form2;
  /**
   * @param receiver
   */
  public DoReturnWork(LibraryManager receiver) {
    super(Label.RETURN_WORK, receiver);
    _userId = _form.addIntegerInput(Message.requestUserId());
    _workId = _form.addIntegerInput(Message.requestWorkId());
    _form2 = new Form();
    _wantsToPay = _form2.addBooleanInput(Message.requestFinePaymentChoice());
  }

  /** @see pt.tecnico.po.ui.Command#execute() */
  @Override
  public final void execute() throws DialogException {
    _form.parse();
    int userId= _userId.value();
    int workId= _workId.value();
    int fine;
    try {
      fine = _receiver.returnWork(workId, userId);
      if (fine>0){
        _display.popup(Message.showFine(userId,fine));
        _form2.parse();

        if (_wantsToPay.value()){
          _receiver.payAllFines(userId);
        }
      }
    }catch (WorkWasntBorrowedException wwbe) {
      throw new WorkNotBorrowedByUserException(workId,userId);
    }catch (WorkDoesntExistException wdee){
      throw new NoSuchWorkException(workId);
    }catch (UserDoesntExistException udee){
      throw new NoSuchUserException(userId);
    }catch (UserActiveException uae){
      throw new UserIsActiveException(userId);
    }
  }

}
